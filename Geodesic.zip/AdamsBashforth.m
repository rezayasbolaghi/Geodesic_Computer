function Y = AdamsBashforth(Func,Cons,h,X)

Ordr = size(X,1);
Y = X(Ordr,:);
for i = 1:Ordr
	Y = Y + h * Cons(i,1) * Func(X(i,:));
end

end