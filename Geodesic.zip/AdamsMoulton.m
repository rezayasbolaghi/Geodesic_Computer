function Y = AdamsMoulton(Func,Cons,h,X)

Ordr = size(X,1);
Z = AdamsBashforth(Func,Cons,h,X);
Conv = 1;
while(Conv > 1e-10)
	Y = X(Ordr,:) + h * Cons(Ordr + 1,2) * Z;
	for i = 1:Ordr
		Y = Y + h * Cons(i,2) * Func(X(i,:));
	end
	Conv = (norm(Y) - norm(Z)) / norm(Y); Z = Y;
end

end