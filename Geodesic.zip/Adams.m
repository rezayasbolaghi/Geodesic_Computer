function Cons = Adams(Ordr)

Cons = zeros(Ordr + 1,2);
syms u v;

% Adams-Bashforth
for j = 0:Ordr - 1
	v = 1 / (u + j);
	for i = 0:Ordr - 1
			v = v * (u + i);
	end
	Cons(Ordr - j,1) = (-1) ^ j / factorial(j) / factorial(Ordr - j - 1) * double(int(v, u, 0, 1));
end

% Adams-Moulton
for j = 0:Ordr
	v = 1 / (u + j - 1);
	for i = 0:Ordr
			v = v * (u + i - 1);
	end
	Cons(Ordr - j + 1,2) = (-1) ^ j / factorial(j) / factorial(Ordr - j) * double(int(v, u, 0, 1));
end

end