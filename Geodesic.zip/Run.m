clc;
clear;

addpath('Surface');

P = input('Enter surface name: ','s');
O = input('Enter order of Adams�Moulton solver: ');
Step = input('Enter number of steps: ');
Dlta = input('Enter step size: ');

switch P
	case 'Sphere'
		Func = @SphereD;
		Surf = @SphereS;
	case 'Ellipse'
		Func = @EllipseD;
		Surf = @EllipseS;
	case 'Cylinder'
		Func = @CylinderD;
		Surf = @CylinderS;
	case 'Saddle'
		Func = @SaddleD;
		Surf = @SaddleS;
end

Data = zeros(Step + 1,4);

Data(1,1) = input('Enter initial condition "Alpha": ');
Data(1,2) = input('Enter initial condition "Beta" : ');
Data(1,3) = input('Enter initial condition "a"    : ');
Data(1,4) = input('Enter initial condition "b"    : ');

for i = 1:Step
    if(i <= O)
        N = i;
        Cons = Adams(i);
    end
    Data(i + 1,:) = AdamsMoulton(Func,Cons,Dlta,Data(i + 1 - N : i,:));
end

figure;
	XYZ = Surf(Data(1:Step,1),Data(1:Step,2));
	plot3(XYZ(:,1),XYZ(:,2),XYZ(:,3));