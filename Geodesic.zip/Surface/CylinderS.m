function XYZ = CylinderS(U,V)

XYZ = [sin(U), cos(U), V];

end