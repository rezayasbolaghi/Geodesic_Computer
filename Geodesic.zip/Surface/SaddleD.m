function Y = SaddleD(X)

Al = X(1);
Bt = X(2);

Al2 = X(1) * X(1);
Bt2 = X(2) * X(2);

TA = Al2 - Bt2;
TB = 1 + 36 * Al2 * Bt2;
TC = 1 + 9 * TA ^ 2;

A1 = 648 * Al * Bt2 * TA * TA;
B1 = - 36 * TA;
C1 = Al * (  36 * TB * (3 * Bt2 - Al2) ...
           - 72 * Bt2 * TB ...
           + 1296 * Al2 * Bt2 * TA);

A2 = Bt * (  36 * TC * (Bt2 - 3 * Al2) ...
           + 36 * TA * TC ...
           + 648 * Al2 * TA * TA);
B2 = 72 * Al * Bt2;
C2 = Bt * (  72 * Al2 * TC ...
           + 648 * Al2 * TA * (3 * Bt2 - Al2) ...
           - 1296 * Al2 * Bt2 * TA);

H = - 2 * TC;

L = X(3) * X(3);
M = X(3) * X(4);
N = X(4) * X(4);

Y(1) = X(3);
Y(2) = X(4);
Y(3) = X(1) * (A1 * L + B1 * M + C1 * N) / H;
Y(4) = X(2) * (A2 * L + B2 * M + C2 * N) / H;
		
end