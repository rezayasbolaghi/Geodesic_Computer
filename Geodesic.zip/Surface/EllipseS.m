function XYZ = EllipseS(U,V)

XYZ = [U, V, sqrt(1 - U .* U - V .* V / 4)];

end