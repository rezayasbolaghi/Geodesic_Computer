function XYZ = SaddleS(U,V)

XYZ = [U, V, U .^ 3 - 3 * U .* V .^ 2];

end