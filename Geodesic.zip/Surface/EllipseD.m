function Y = EllipseD(X)

A = X(1)^2;
B = X(2)^2;
C = 1 - A - B / 4;
D = C * (16 * (C + A) + B);

A = (1 - A) / D;
B = (1 - B / 4) / D;
C = (X(1) * X(2)) / D;

L = X(3) * X(3);
M = X(3) * X(4);
N = X(4) * X(4);

Y(1) = X(3);
Y(2) = X(4);
Y(3) = X(1) * (-16 * B * L - 8 * C * M - 4 * A * N);
Y(4) = X(2) * (- 4 * B * L - 2 * C * M -     A * N);
		
end