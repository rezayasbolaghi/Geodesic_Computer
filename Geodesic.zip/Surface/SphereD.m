function Y = SphereD(X)

A = 1 - X(1)^2;
B = 1 - X(2)^2;
D = A + B - 1;

A = A / D;
B = B / D;
C = (2 * X(1) * X(2)) / D;

L = X(3) * X(3);
M = X(3) * X(4);
N = X(4) * X(4);

Y(1) = X(3);
Y(2) = X(4);
Y(3) = X(1) * ( B * L - C * M - A * N);
Y(4) = X(2) * (-B * L - C * M + A * N);
	
end