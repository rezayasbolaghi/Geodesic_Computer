function XYZ = SphereS(U,V)

XYZ = [U, V, sqrt(1 - U .* U - V .* V)];

end