function Y = CylinderD(X)

Y(1) = X(3);
Y(2) = X(4);
Y(3) = 0;
Y(4) = 0;
	
end